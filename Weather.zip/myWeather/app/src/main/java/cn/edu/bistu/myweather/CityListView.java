package cn.edu.bistu.myweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.ArrayList;

import cn.edu.bistu.myweather.db.City;
import cn.edu.bistu.myweather.db.County;
import cn.edu.bistu.myweather.util.HttpUtil;
import cn.edu.bistu.myweather.util.Utility;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

//整个activity和ProvinceList.activity几乎没有差别
public class CityListView extends AppCompatActivity {

    private City selectedCity;//点击的城市
    private County selectedCounty;//点击的城市
    ArrayList<City> cityList = new ArrayList<>();//城市的列表
    ArrayList<County> countyList = new ArrayList<>();//城市的列表
    ArrayList<String> list = new ArrayList<>();
    ListView listView;//listview
    ArrayAdapter<String> adapter;//适配器

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_list_view);

        Intent intent = getIntent();
        int provinceCode = intent.getIntExtra("provinceCode", 0);
        String provinceName = intent.getStringExtra("provinceName");

        DataSupport.deleteAll("City");
        String address = "http://guolin.tech/api/china/" + provinceCode;

        HttpUtil.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程处理逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = Utility.handleCityResponse(responseText, provinceCode);
                if (result) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            queryCities();
                        }
                    });
                }
            }
        });

        TextView titleText = (TextView) findViewById(R.id.title_text);//标题名
        Button backVisit = (Button) findViewById(R.id.back_visit);//返回输入id界面

        listView = (ListView) findViewById(R.id.list_view);//listview
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);//适配器
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(CityListView.this, CountyList.class);
                selectedCity = cityList.get(i);
                intent.putExtra("cityCode", selectedCity.getCityCode());
                intent.putExtra("provinceName", provinceName);
                intent.putExtra("provinceCode",provinceCode);
                intent.putExtra("cityName", selectedCity.getCityName());
                startActivity(intent);
            }
        });


        backVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CityListView.this, ProvinceList.class);
                startActivity(i);
            }
        });
    }

    private void queryCities() {
        Intent intent = getIntent();
        int provinceCode = intent.getIntExtra("provinceCode", 0);
        cityList = (ArrayList<City>) DataSupport.where("provincecode = ?", String.valueOf(provinceCode)).find(City.class);
        if (cityList.size() > 0) {
            list.clear();
            for (City city : cityList) {
                list.add(city.getCityName());
            }
            adapter.notifyDataSetChanged();
            listView.setSelection(0);
        } else {
            String address = "http://guolin.tech/api/china/" + provinceCode;
            queryFromServer(address, "city");
        }
    }

    private void queryFromServer(String adress, final String type) {
        HttpUtil.sendOkHttpRequest(adress, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程处理逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Intent intent = getIntent();
                int provinceId = intent.getIntExtra("provinceId", 0);

                String responseText = response.body().string();
                boolean result = false;
                if ("city".equals(type)) {
                    result = Utility.handleCityResponse(responseText, provinceId);
                }
                if (result) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if ("city".equals(type)) {
                                queryCities();
                            }
                        }
                    });
                }
            }
        });
    }

}