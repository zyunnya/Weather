package cn.edu.bistu.myweather.gson;

public class Weather {

    public String status;

    public Basic basic;

    public Now now;

}
