package cn.edu.bistu.myweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.ArrayList;

import cn.edu.bistu.myweather.db.Province;
import cn.edu.bistu.myweather.util.HttpUtil;
import cn.edu.bistu.myweather.util.Utility;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class ProvinceList extends AppCompatActivity {

    private Province selectedPro;//点击的省份

    private ArrayList<Province> provinceList = new ArrayList<>();//省的列表

    private ArrayList<String> list = new ArrayList<>();
    private ListView listView;//listview
    private ArrayAdapter<String> adapter;//适配器
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_province_list);

        //首先利用api和数据库得到所有的省份
        DataSupport.deleteAll("Province");
        provinceList = (ArrayList<Province>) DataSupport.findAll(Province.class);
        String address = "http://guolin.tech/api/china";
        HttpUtil.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程处理逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText( getApplicationContext(),"加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = Utility.handleProvinceResponse(responseText);
                if(result){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            queryProvinces();
                        }
                    });
                }
            }
        });

        //设置适配器
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);

        TextView titleText = (TextView) findViewById(R.id.title_text);//标题名
        Button backVisit = (Button) findViewById(R.id.back_visit);//返回输入id界面

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {//listView的点击事件
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedPro = provinceList.get(i);
                Intent intent = new Intent(ProvinceList.this , CityListView.class);
                intent.putExtra("provinceCode",selectedPro.getProvinceCode());
                intent.putExtra("provinceName",selectedPro.getProvinceName());
                startActivity(intent);
            }
        });


        backVisit.setOnClickListener(new View.OnClickListener() {//返回访问界面按钮的点击事件
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ProvinceList.this, Visit.class);
                startActivity(i);
            }
        });
    }

    //首先先判断数据库中有没有数据，有的话则直接把这些数据设置给list，没有的话则写一个api地址启用queryFromServer
    private void queryProvinces() {
        provinceList = (ArrayList<Province>) DataSupport.findAll(Province.class);
        if(provinceList.size() > 0){
            list.clear();
            for(Province province : provinceList){
                list.add(province.getProvinceName());
            }
            adapter.notifyDataSetChanged();
            listView.setSelection(0);
        }else{
            String address = "http://guolin.tech/api/china";
            queryFromServer(address,"province");
        }
    }

    //通过参数api地址，使用okhttp和服务器做访问请求，得到数据
    private void queryFromServer(String adress,final String type){
        HttpUtil.sendOkHttpRequest(adress, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程处理逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText( getApplicationContext(),"加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = false;
                if("province".equals(type)){
                    result = Utility.handleProvinceResponse(responseText);
                }
                if(result){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if("province".equals(type)){
                                queryProvinces();
                            }
                        }
                    });
                }
            }
        });
    }
}
