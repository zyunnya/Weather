package cn.edu.bistu.myweather.gson;

import com.google.gson.annotations.SerializedName;

public class Basic {//gson返回数据中的basic

    @SerializedName("parent_city")//由于json一些字段可能不太适合直接作为java命名字段，利用SerializedName让json字段和java字段间建立映射关系
    public String cityName;

    @SerializedName("id")
    public String weatherId;

    public Update update;

    public class Update{
        @SerializedName("loc")
        public String updateTime;
    }

    @SerializedName("admin_area")
    public String provinceName;

    @SerializedName("location")
    public String countyName;

}
