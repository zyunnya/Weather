package cn.edu.bistu.myweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.ArrayList;

import cn.edu.bistu.myweather.db.County;
import cn.edu.bistu.myweather.util.HttpUtil;
import cn.edu.bistu.myweather.util.Utility;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

//和CityListView几乎没有差别
public class CountyList extends AppCompatActivity {

    private County selectedCounty;//点击的城市
    ArrayList<County> countyList = new ArrayList<>();//城市的列表
    ArrayList<String> list = new ArrayList<>();
    ListView listView;//listview
    ArrayAdapter<String> adapter;//适配器

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_county_list);

        Intent intent = getIntent();
        int provinceCode = intent.getIntExtra("provinceCode",0);
        int cityCode = intent.getIntExtra("cityCode",0);
        String provinceName = intent.getStringExtra("provinceName");
        String cityName = intent.getStringExtra("cityName");

        DataSupport.deleteAll("County");
        String address = "http://guolin.tech/api/china/" + provinceCode + "/" + cityCode;

        HttpUtil.sendOkHttpRequest(address, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程处理逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText( getApplicationContext(),"加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = Utility.handleCountyResponse(responseText,cityCode);
                if(result){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            queryCounties();
                        }
                    });
                }
            }
        });


        TextView titleText = (TextView) findViewById(R.id.title_text);//标题名
        Button backVisit = (Button) findViewById(R.id.back_visit);//返回输入id界面

        listView = (ListView) findViewById(R.id.list_view);//listview
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);//适配器
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedCounty = countyList.get(i);
                Intent intent = new Intent(CountyList.this, WeatherView.class);
                intent.putExtra("weather_id",selectedCounty.getWeatherId());
                intent.putExtra("provinceName",provinceName);
                intent.putExtra("cityName",cityName);
                intent.putExtra("provinceCode",provinceCode);
                intent.putExtra("cityCode",selectedCounty.getCityCode());
                intent.putExtra("judgeFrom",0);
                intent.putExtra("whereFrom",1);
                if(i != 0){
                    intent.putExtra("countyName",selectedCounty.getCountyName());
                }else{
                    intent.putExtra("countyName","");
                }
                startActivity(intent);
            }
        });


        backVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CountyList.this, CityListView.class);
                i.putExtra("provinceCode",provinceCode);
                startActivity(i);
            }
        });
    }

    private void queryCounties() {
        Intent intent = getIntent();
        int provinceCode = intent.getIntExtra("provinceCode",0);
        int cityCode = intent.getIntExtra("cityCode",0);

        countyList = (ArrayList<County>) DataSupport.where("citycode = ?",String.valueOf(cityCode)).find(County.class);
        if(countyList.size() > 0){
            list.clear();
            for(County  county: countyList){
                list.add(county.getCountyName());
            }
            adapter.notifyDataSetChanged();
            listView.setSelection(0);
        }else{
            String address = "http://guolin.tech/api/china/" + provinceCode + "/" + cityCode;
            queryFromServer(address,"county");
        }
    }

    private void queryFromServer(String adress,final String type){
        HttpUtil.sendOkHttpRequest(adress, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程处理逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText( getApplicationContext(),"加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Intent intent = getIntent();
                int cityCode = intent.getIntExtra("cityCode",0);
                String responseText = response.body().string();
                boolean result = false;
                if("county".equals(type)){
                    result = Utility.handleCountyResponse(responseText,cityCode);
                }
                if(result){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if("county".equals(type)){
                                queryCounties();
                            }
                        }
                    });
                }
            }
        });
    }
}