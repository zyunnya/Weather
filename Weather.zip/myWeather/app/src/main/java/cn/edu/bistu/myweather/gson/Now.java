package cn.edu.bistu.myweather.gson;

import com.google.gson.annotations.SerializedName;

public class Now {

    @SerializedName("tmp")//由于json一些字段可能不太适合直接作为java命名字段，利用SerializedName让json字段和java字段间建立映射关系
    public String temperature;

    @SerializedName("hum")
    public String humidity;

    @SerializedName("cond")
    public More more;

    public class More{
        @SerializedName("txt")
        public String info;
    }

}
