package cn.edu.bistu.myweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import cn.edu.bistu.myweather.db.DatabaseHelper;
import cn.edu.bistu.myweather.gson.Weather;
import cn.edu.bistu.myweather.util.HttpUtil;
import cn.edu.bistu.myweather.util.Utility;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class WeatherView extends AppCompatActivity {
    private DatabaseHelper dbHelper;

    TextView AreaText;//地区文本
    TextView TimeText;//时间文本
    TextView MeteorologicalText;//天气文本
    TextView TemperatureText;//温度文本
    TextView HumidityText;//湿度文本


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_view);

        Intent intent1 = getIntent();
        int judgeFrom = intent1.getIntExtra("judgeFrom",-1);
        int provinceCode = intent1.getIntExtra("provinceCode",0);
        int cityCode = intent1.getIntExtra("cityCode",0);
        String weatherId = intent1.getStringExtra("weather_id");
        dbHelper = new DatabaseHelper(this,"RecordDb.db",null,1);//数据库
        SQLiteDatabase db = dbHelper.getWritableDatabase();//得到能够操作数据库的db

        AreaText = (TextView) findViewById(R.id.AreaText);//初始化地区文本
        TimeText = (TextView) findViewById(R.id.TimeText);//初始化时间文本
        MeteorologicalText = (TextView) findViewById(R.id.MeteorologicalText);//初始化天气文本
        TemperatureText = (TextView) findViewById(R.id.TemperatureText);//初始化温度文本
        HumidityText = (TextView) findViewById(R.id.HumidityText);//初始化湿度文本

        Button FollowButton = (Button) findViewById(R.id.FollowButton);
        Button ReturnButton = (Button) findViewById(R.id.ReturnButton);
        Button RefreshButton = (Button) findViewById(R.id.RefreshButton);



        if(judgeFrom == 1 || judgeFrom == 0){//根据传来的judgeFrom的值判断是从哪个activity跳转来的，1代表关注列表，0代表区县列表，-1代表查询来的
            String provinceName = intent1.getStringExtra("provinceName");
            String cityName = intent1.getStringExtra("cityName");
            String countyName = intent1.getStringExtra("countyName");

            //用Cursor得到数据库里的对应天气代码的数据
            Cursor cursor = db.query("old_weather",null,"w_weatherId like ?",new String[]{String.valueOf(weatherId)},null,null,null);

            //如果moveToFirst为真代表有数据
            if(cursor.moveToFirst() == true){//开始循环得到数据,则利用这里的数据显示到对应的文本
                String updateTime = cursor.getString(cursor.getColumnIndex("w_time"));
                String meteorological = cursor.getString(cursor.getColumnIndex("w_meteorological"));
                String temperature = cursor.getString(cursor.getColumnIndex("w_temperature"));
                String humidity = cursor.getString(cursor.getColumnIndex("w_humidity"));
                if(countyName.equals("")){
                    AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName);
                }else{
                    AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName + "   " + "区:" + countyName);
                }

                TimeText.setText("更新时间:" + updateTime);
                MeteorologicalText.setText("天气:" + meteorological);
                TemperatureText.setText("温度:" + temperature);
                HumidityText.setText("湿度:" + humidity);
            }else{//没有则直接访问api
                requestWeather(weatherId,0);
            }
            cursor.close();//关闭cursork
        }else{//否则是查询省份代码和城市代码来看天气的
            requestWeather(weatherId,2);
        }

        Cursor cursor2 = db.query("follow",null,"f_weatherId like ?",new String[]{String.valueOf(weatherId)},null,null,null);
        if(cursor2.moveToFirst() == true){//开始循环得到数据,为真表示已经在关注列表里
            FollowButton.setText("取消关注");
        }else{
            FollowButton.setText("关注");
        }

        FollowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(FollowButton.getText().toString().equals("关注")){//根据文本判断，“关注”代表还关注，则插入到数据库中
                    ContentValues values = new ContentValues();//开始编写insert信息
                    Intent intent = getIntent();
                    String weatherId = intent.getStringExtra("weather_id");
                    String cityName = intent.getStringExtra("cityName");
                    String countyName = intent.getStringExtra("countyName");
                    String provinceName = intent.getStringExtra("provinceName");
                    values.put("f_provinceName",provinceName);
                    values.put("f_cityName", cityName);
                    values.put("f_countyName",countyName);
                    values.put("f_weatherId",weatherId);
                    db.insert("follow",null,values);
                    FollowButton.setText("取消关注");
                }else{//否则代表已经在数据库里，直接删除
                    db.delete("follow","f_weatherId = ?",new String[]{String.valueOf(weatherId)});//把指定的id的那一数据删除
                    FollowButton.setText("关注");
                }
            }
        });
        cursor2.close();//关闭cursork

        ReturnButton.setOnClickListener(new View.OnClickListener() {//根据judgeFrom的值返回对应的activity
            @Override
            public void onClick(View view) {
                Intent in = getIntent();
                if(judgeFrom == 0){
                    String cityName = in.getStringExtra("cityName");
                    String provinceName = in.getStringExtra("provinceName");
                    Intent intent = new Intent(WeatherView.this,CountyList.class);
                    intent.putExtra("provinceCode",provinceCode);
                    intent.putExtra("cityName",cityName);
                    intent.putExtra("cityCode",cityCode);
                    intent.putExtra("provinceName",provinceName);
                    startActivity(intent);
                }else if(judgeFrom == 1){
                    Intent intent = new Intent(WeatherView.this,FollowList.class);
                    startActivity(intent);
                }else{
                    Intent intent = new Intent(WeatherView.this,Visit.class);
                    startActivity(intent);
                }

            }
        });

        RefreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                String weatherId = intent.getStringExtra("weather_id");
                requestWeather(weatherId,1);
            }
        });

    }

    public void requestWeather(final String weatherId,int judge){
        String weatherUrl = "http://guolin.tech/api/weather?cityid=" + weatherId + "&key=5b4bbc2c9e404470b5fda2de191fdb60";//利用url地址访问天气信息
        HttpUtil.sendOkHttpRequest(weatherUrl, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String responseText = response.body().string();//得到response
                final Weather weather = Utility.handleWeatherResponse(responseText);//调用handle得到天气对象
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(weather != null && "ok".equals(weather.status)){
                            if(judge == 0){//参数是0则是第一次访问的天气，转1
                                showWeatherInfo1(weather);
                            }else if(judge == 1){//参数是1则是访问过的天气，转2
                                showWeatherInfo2(weather);
                            }else{//其他则是通过省份代码和城市代码查询来的天气，仅仅显示不存到数据库，转3
                                showWeatherInfo3(weather);
                            }

                        }else{
                            Toast.makeText(WeatherView.this, "获取天气信息失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    public void showWeatherInfo1(Weather weather){//第一次访问到的数据会存到数据库中
        String provinceName = weather.basic.provinceName;
        String cityName = weather.basic.cityName;
        String countyName = weather.basic.countyName;
        String updateTime = weather.basic.update.updateTime;
        String temperature = weather.now.temperature + "℃";
        String humidity = weather.now.humidity + "%";
        String weatherInfo = weather.now.more.info;
        //以上为先从weather中得到参数
        //以下为设置文本信息
        if(countyName.equals(cityName)){
            AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName);
        }else{
            AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName + "   " + "区:" + countyName);
        }
        TimeText.setText("更新时间:" + updateTime);
        MeteorologicalText.setText("天气:" + weatherInfo);
        TemperatureText.setText("温度:" + temperature);
        HumidityText.setText("湿度:" + humidity);

        //以下为保存到数据库的语句
        DatabaseHelper dbHelper = new DatabaseHelper(this,"RecordDb.db",null,1);//数据库
        SQLiteDatabase db = dbHelper.getWritableDatabase();//读取数据库信息
        ContentValues values = new ContentValues();//开始编写insert信息
        values.put("w_provinceName",provinceName);
        values.put("w_cityName",cityName );
        values.put("w_countyName",countyName);
        values.put("w_time",updateTime);
        values.put("w_meteorological",weatherInfo);
        values.put("w_temperature",temperature);
        values.put("w_humidity",humidity);

        Intent intent = getIntent();
        String weatherId = intent.getStringExtra("weather_id");
        values.put("w_weatherId",weatherId);

        db.insert("old_weather",null,values);
    }

    public void showWeatherInfo2(Weather weather){//点击刷新会调用这个方法，用api得到新的天气信息并修改数据库
        String provinceName = weather.basic.provinceName;
        String cityName = weather.basic.cityName;
        String updateTime = weather.basic.update.updateTime;
        String temperature = weather.now.temperature + "℃";
        String humidity = weather.now.humidity + "%";
        String weatherInfo = weather.now.more.info;
        String countyName = weather.basic.countyName;
        if(countyName.equals(cityName)){
            AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName);
        }else{
            AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName + "   " + "区:" + countyName);
        }
        TimeText.setText("更新时间:" + updateTime);
        MeteorologicalText.setText("天气:" + weatherInfo);
        TemperatureText.setText("温度:" + temperature);
        HumidityText.setText("湿度:" + humidity);

        //以下为修改数据库的语句
        DatabaseHelper dbHelper = new DatabaseHelper(this,"RecordDb.db",null,1);//数据库
        SQLiteDatabase db = dbHelper.getWritableDatabase();//读取数据库信息
        ContentValues values = new ContentValues();//开始编写update信息
        values.put("w_time",updateTime);
        values.put("w_meteorological",weatherInfo);
        values.put("w_temperature",temperature);
        values.put("w_humidity",humidity);

        Intent intent = getIntent();
        String weatherId = intent.getStringExtra("weather_id");
        db.update("old_weather",values,"w_weatherId = ?",new String[]{weatherId});
    }

    public void showWeatherInfo3(Weather weather){//通过代码查询的城市天气数据仅仅显示，而不对数据库进行操作
        String provinceName = weather.basic.provinceName;
        String cityName = weather.basic.cityName;
        String countyName = weather.basic.countyName;
        String updateTime = weather.basic.update.updateTime;
        String temperature = weather.now.temperature + "℃";
        String humidity = weather.now.humidity + "%";
        String weatherInfo = weather.now.more.info;
        if(countyName.equals(cityName)){
            AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName);
        }else{
            AreaText.setText("省份:" + provinceName + "   " + "城市:" + cityName + "   " + "区:" + countyName);
        }
        TimeText.setText("更新时间:" + updateTime);
        MeteorologicalText.setText("天气:" + weatherInfo);
        TemperatureText.setText("温度:" + temperature);
        HumidityText.setText("湿度:" + humidity);
    }

}