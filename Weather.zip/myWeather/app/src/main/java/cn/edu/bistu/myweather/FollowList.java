package cn.edu.bistu.myweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

import cn.edu.bistu.myweather.db.DatabaseHelper;

//根据follow表里的值显示成ListView
public class FollowList extends AppCompatActivity {
    private DatabaseHelper dbHelper;//DatabaseHelper对象用来进行数据库操作

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow_list);

        dbHelper = new DatabaseHelper(this,"RecordDb.db",null,1);//数据库
        SQLiteDatabase db = dbHelper.getWritableDatabase();//得到能够操作数据库的db

        ArrayList<String> cityList = new ArrayList<String>();//得到从访问界面传来的城市列表
        ArrayList<String> intentCityList = new ArrayList<String>();//得到从访问界面传来的城市列表
        ArrayList<String> provinceList = new ArrayList<String>();//得到从访问界面传来的城市列表
        ArrayList<String> countyList = new ArrayList<String>();
        ArrayList<String> weatherList = new ArrayList<String>();//得到从访问界面传来的城市列表

        String sql = "select * from follow";
        Cursor cursor = db.rawQuery(sql,null);
        if(cursor.moveToFirst()){//开始循环得到数据
            do{
                //遍历Cursor对象，取出数据并打印
                String  provinceName = cursor.getString(cursor.getColumnIndex("f_provinceName"));//得到省名
                String  cityName = cursor.getString(cursor.getColumnIndex("f_cityName"));//得到城市名
                String countyName = cursor.getString(cursor.getColumnIndex("f_countyName"));
                String  weatherId = cursor.getString(cursor.getColumnIndex("f_weatherId"));//得到天气id
                provinceList.add(provinceName);//省名存到列表里
                intentCityList.add(cityName);
                if(!countyName.equals("")){
                    cityList.add(cityName + "市" + countyName + "区");//城市名存到列表里
                }else{
                    cityList.add(cityName + "市");//城市名存到列表里
                }

                weatherList.add(weatherId);//天气id存到列表里
                countyList.add(countyName);
            }while(cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,cityList);//适配器
        ListView listView = (ListView) findViewById(R.id.list_view);//得到ListView
        listView.setAdapter(adapter);//设置适配器
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {//ListView的点击事件
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String provinceName = provinceList.get(i);//得到所选中的那一栏省名
                String cityName = intentCityList.get(i);//得到所选中的那一栏的城市名
                String countyName = countyList.get(i);
                String weatherId = weatherList.get(i);//得到所选中的那一栏的天气id
                Intent intent = new Intent(FollowList.this , WeatherView.class);//跳转
                intent.putExtra("provinceName",provinceName);//把省名传过去
                intent.putExtra("cityName",cityName);//把省名传过去
                intent.putExtra("weather_id",weatherId);//把省名传过去
                if(countyName.equals(cityName)){
                    intent.putExtra("countyName","");
                }else{
                    intent.putExtra("countyName",countyName);
                }
                intent.putExtra("judgeFrom",1);
                startActivity(intent);//开始跳转
            }
        });

        Button backVisit = (Button) findViewById(R.id.back_visit);
        backVisit.setOnClickListener(new View.OnClickListener() {//返回访问界面按钮的点击事件
            @Override
            public void onClick(View view) {
                Intent i = new Intent(FollowList.this, Visit.class);
                startActivity(i);
            }
        });

    }
}