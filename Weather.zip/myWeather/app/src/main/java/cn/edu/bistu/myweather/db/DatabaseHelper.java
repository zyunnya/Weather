package cn.edu.bistu.myweather.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String CREATE_OLDWEATHER = "create table old_weather("
            + "w_id integer primary key autoincrement, w_provinceName varchar,"
            + "w_cityName varchar, w_countyName varchar,w_time text, w_meteorological varchar,w_temperature integer,w_humidity integer,w_weatherId text)";

    public static final String CREATE_FOLLOW = "create table follow("
            + "f_id integer primary key autoincrement, f_provinceName varchar,f_cityName varchar,f_countyName varchar,"
            + "f_weatherId varchar)";

    private Context mContext;

    public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version){
        super(context,name,factory,version);
        mContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_OLDWEATHER);
        db.execSQL(CREATE_FOLLOW);

        Toast.makeText(mContext, "數據庫創建成功", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldV, int newV) {

    }
}
