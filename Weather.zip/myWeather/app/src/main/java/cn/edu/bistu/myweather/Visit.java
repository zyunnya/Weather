package cn.edu.bistu.myweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.litepal.crud.DataSupport;

import java.io.IOException;
import java.util.ArrayList;

import cn.edu.bistu.myweather.db.City;
import cn.edu.bistu.myweather.db.County;
import cn.edu.bistu.myweather.db.DatabaseHelper;
import cn.edu.bistu.myweather.db.Province;
import cn.edu.bistu.myweather.util.HttpUtil;
import cn.edu.bistu.myweather.util.Utility;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class Visit extends AppCompatActivity {

    ArrayList<Province> provinceList = new ArrayList<>();
    ArrayList<City> cityList = new ArrayList<>();
    ArrayList<County> countyList = new ArrayList<>();

    private int currentLevel;  //当前被选中的级别
    private Province selectedProvince;//被选中的省份
    private City selectedCity;//被选中的城市
    private County selectedCounty;

    TextView provinceId;
    TextView cityId;

    private DatabaseHelper dbHelper;//DatabaseHelper对象用来进行数据库操作

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visit);

        dbHelper = new DatabaseHelper(this, "weather_DB.db", null, 1);
        SQLiteDatabase db = dbHelper.getWritableDatabase();//得到能够操作数据库的db

        provinceId = (TextView) findViewById(R.id.provinceId);
        cityId = (TextView) findViewById(R.id.cityId);
        Button checkWeather = (Button) findViewById(R.id.checkWeather);


        checkWeather.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                //先利用省份代码文本和城市代码文本里的代码组合成api地址得到区县，把这些区县全都存到CountyList中
                DataSupport.deleteAll("County");
                DataSupport.deleteAll("City");
                String address = "http://guolin.tech/api/china/" + provinceId.getText().toString() + "/" + cityId.getText().toString();

                HttpUtil.sendOkHttpRequest(address, new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        //通过runOnUiThread方法回到主线程处理逻辑
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(getApplicationContext(), "加载失败", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        String responseText = response.body().string();
                        boolean result = Utility.handleCityResponse(responseText, Integer.parseInt(cityId.getText().toString()));
                        if (result) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    queryCounties();
                                }
                            });
                        }
                    }
                });


                if (countyList.size() <= 0) {//如果countyList长度小于等于0代表没有这个城市，意味着代码错误
                    Toast.makeText(getApplicationContext(), "ID错误，请重新输入", Toast.LENGTH_SHORT).show();
                } else {//否则代表有这个城市，传送weatherView所需要的参数，然后做跳转
                    selectedCounty = countyList.get(0);
                    Intent intent = new Intent(Visit.this, WeatherView.class);
                    intent.putExtra("weather_id", selectedCounty.getWeatherId());
                    intent.putExtra("whereFrom", 0);
                    intent.putExtra("judgeFrom", -1);
                    intent.putExtra("provinceCode", Integer.parseInt(provinceId.getText().toString()));
                    intent.putExtra("cityCode", Integer.parseInt(cityId.getText().toString()));
                    intent.putExtra("countyName", selectedCounty.getCountyName());
                    startActivity(intent);
                }

            }


        });

        Button followList = (Button) findViewById(R.id.followList);
        followList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(Visit.this, FollowList.class);
                startActivity(intent2);
            }
        });

        Button checkAll = (Button) findViewById(R.id.checkAll);
        checkAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inten3 = new Intent(Visit.this, ProvinceList.class);
                startActivity(inten3);
            }
        });

    }

    private void queryCounties() {
        int provinceCode = Integer.parseInt(provinceId.getText().toString());
        int cityCode = Integer.parseInt(cityId.getText().toString());
        countyList = (ArrayList<County>) DataSupport.where("citycode = ?", String.valueOf(cityCode)).find(County.class);
        String address = "http://guolin.tech/api/china/" + provinceCode + "/" + cityCode;
        queryFromServer(address, "county");
    }

    private void queryFromServer(String address, final String type) {
        HttpUtil.sendOkHttpRequest(address, new Callback() {
            //请求加载失败
            @Override
            public void onFailure(Call call, IOException e) {
                //通过runOnUiThread方法回到主线程逻辑
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(), "加载失败", Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseText = response.body().string();
                boolean result = false;
                if ("county".equals(type)) {
                    result = Utility.handleCountyResponse(responseText, Integer.parseInt(cityId.getText().toString()));
                }
                if (result) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            queryCounties();
                        }
                    });
                }
            }
        });
    }
}